q4.b
